__('Save as Template', 'elementor');
__('Preview Changes', 'elementor');
__('Save Draft', 'elementor');
__('Save Options', 'elementor');
__('Publish', 'elementor');
__('Submit', 'elementor');